const express = require('express');
const router = express.Router();
const Item = require('../models/Item');

// Get items with pagination
router.get('/', async (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    try {
        const items = await Item.find().skip(skip).limit(limit);
        const total = await Item.countDocuments();
        res.json({
            items,
            total,
            page,
            pages: Math.ceil(total / limit),
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
