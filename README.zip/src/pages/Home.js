import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
    return (
        <div className="home">
            <h1>Home is Where My Plants Are</h1>
            <p>Welcome to the Plant Shop!</p>
            <Link to="/plants" className="button">Go Shopping</Link>
        </div>
    );
};

export default Home;
