import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './PlantList.css';

// Import images with correct case-sensitive paths
import monstera from '../assets/Monstera.jpg';
import fiddleLeafFig from '../assets/FiddleLeafFig.jpg';
import aloeVera from '../assets/AloeVera.jpg';
import peaceLily from '../assets/PeaceLily.jpg';
import pothos from '../assets/Pothos.jpg';
import snakePlant from '../assets/SnakePlant.jpg';
import spiderPlant from '../assets/SpiderPlant.jpg';
import zzPlant from '../assets/ZZPlant.jpg';

const imageMap = {
    "Monstera": monstera,
    "Fiddle Leaf Fig": fiddleLeafFig,
    "Aloe Vera": aloeVera,
    "Peace Lily": peaceLily,
    "Pothos": pothos,
    "Snake Plant": snakePlant,
    "Spider Plant": spiderPlant,
    "ZZ Plant": zzPlant,
};

const PlantList = () => {
    const [plants, setPlants] = useState([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);

    useEffect(() => {
        const fetchPlants = async () => {
            try {
                const response = await axios.get(`http://localhost:3001/plants?page=${page}&limit=8`);
                setPlants(response.data.plants);
                setTotalPages(response.data.pages);
            } catch (error) {
                console.error('Error fetching plants', error);
            } finally {
                setLoading(false);
            }
        };

        fetchPlants();
    }, [page]);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (!plants.length) {
        return <div>No plants available.</div>;
    }

    return (
        <div>
            <div className="plant-list">
                {plants.map((plant) => (
                    <div key={plant._id} className="plant-card">
                        <img src={imageMap[plant.name]} alt={plant.name} />
                        <h2>{plant.name}</h2>
                        <p>{plant.description}</p>
                        <Link to={`/plants/${plant._id}`}>View Details</Link>
                    </div>
                ))}
            </div>
            <div className="pagination">
                {Array.from({ length: totalPages }, (_, index) => (
                    <button
                        key={index}
                        onClick={() => setPage(index + 1)}
                        className={index + 1 === page ? 'active' : ''}
                    >
                        {index + 1}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default PlantList;
