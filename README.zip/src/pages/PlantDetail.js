import React, { useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { CartProvider } from '../contexts/CartContext';
import './PlantDetail.css';

const PlantDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { plants, addToCart } = useContext(CartProvider);
    const plant = plants.find((plant) => plant.id === parseInt(id));

    const handleAddToCart = () => {
        const token = localStorage.getItem('token');
        if (!token) {
            navigate('/login');
        } else {
            addToCart(plant);
        }
    };

    if (!plant) {
        return <div>Plant not found</div>;
    }

    return (
        <div className="plant-detail-container">
            <h2>{plant.name}</h2>
            <img src={plant.img} alt={plant.name} />
            <p>{plant.description}</p>
            <p>Price: ${plant.price}</p>
            <button onClick={handleAddToCart}>Add to Cart - ${plant.price}</button>
            <button onClick={() => navigate('/cart')}>View Cart</button>
        </div>
    );
};

export default PlantDetail;
