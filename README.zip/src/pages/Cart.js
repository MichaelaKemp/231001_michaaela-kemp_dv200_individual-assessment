import React from 'react';
import { useCart } from '../contexts/CartContext';
import { Link } from 'react-router-dom';
import './Cart.css';

const Cart = () => {
    const { cartItems, removeFromCart } = useCart();

    if (cartItems.length === 0) {
        return <div className="cart">Your cart is empty</div>;
    }

    return (
        <div className="cart">
            <h2>Your Cart</h2>
            {cartItems.map(item => (
                <div key={item._id} className="cart-item">
                    <img src={item.img} alt={item.name} />
                    <div className="cart-item-details">
                        <h3>{item.name}</h3>
                        <p>{item.description}</p>
                        <p>Price: ${item.price}</p>
                        <button onClick={() => removeFromCart(item._id)}>Remove</button>
                    </div>
                </div>
            ))}
            <Link to="/plants" className="back-to-shopping">Back to Shopping</Link>
        </div>
    );
};

export default Cart;
