import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './NavBar.css';

const NavBar = () => {
    const token = localStorage.getItem('token');
    const navigate = useNavigate();
    let username = '';

    if (token) {
        // Decode the token to get the username (assuming it's stored in the payload)
        const decodedToken = JSON.parse(atob(token.split('.')[1]));
        username = decodedToken.username;
    }

    const handleLogout = () => {
        localStorage.removeItem('token');
        window.location.reload();
    };

    return (
        <nav className="navbar">
            <Link to="/">Home</Link>
            <Link to="/plants">Plants</Link>
            <Link to="/cart">Cart</Link>
            {token ? (
                <>
                    <span>Welcome, {username}</span>
                    <button onClick={handleLogout}>Logout</button>
                </>
            ) : (
                <Link to="/login">Log In</Link>
            )}
        </nav>
    );
};

export default NavBar;
